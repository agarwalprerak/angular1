export class Mobile{
    public mobileId:number;
    public mobileName:string;
    public mobileCost:number;
    constructor(mobileId:number,mobileName:string,mobileCost:number){
        this.mobileId=mobileId;
        this.mobileName=mobileName;
        this.mobileCost=mobileCost;
    }
    printMobileDetails():void{
        console.log(this.mobileId + this.mobileName + this.mobileCost);
    }
}