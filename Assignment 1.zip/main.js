"use strict";
exports.__esModule = true;
var BasicPhone_1 = require("./BasicPhone");
var SmartPhone_1 = require("./SmartPhone");
var phoneData = [];
var phone1 = new SmartPhone_1.SmartPhone(123, "Samsung", 789.99, "Smartphone");
var phone2 = new BasicPhone_1.BasicPhone(124, "Nokia", 189.99, "BasicPhone");
phoneData.push(phone1);
phoneData.push(phone2);
for (var i = 0; i < phoneData.length; i++) {
    phoneData[i].printMobileDetails();
}
