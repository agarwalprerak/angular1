import { Mobile } from "./Mobile";
export class BasicPhone extends Mobile{
    public mobileType:string;
    constructor(mobileId:number,mobileName:string,mobileCost:number,mobileType:string){
        super(mobileId,mobileName,mobileCost);
        this.mobileType=mobileType;
    }
    printMobileDetails():void{
        console.log(this.mobileId + " " + this.mobileName + " " + this.mobileCost + " " + this.mobileType);
    }
}