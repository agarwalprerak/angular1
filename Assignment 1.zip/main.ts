import { BasicPhone } from "./BasicPhone";
import { SmartPhone } from "./SmartPhone";

let phoneData:any=[];
let phone1 = new SmartPhone(123,"Samsung",789.99,"Smartphone");
let phone2 = new BasicPhone(124,"Nokia",189.99,"BasicPhone");
phoneData.push(phone1);
phoneData.push(phone2);
for(let i=0;i<phoneData.length;i++){
    phoneData[i].printMobileDetails();
}